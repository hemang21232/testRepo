# #!/home/djgo/djangoContent/django-env/bin/python python3

import datetime
with open("/home/djgo/djangoContent/required_f", "w") as f:
    f.write(f"OK_CAT time {datetime.datetime.now():%Y-%m-%d %H:%M:%S}\n")

# in system file
# ExecStart=/home/djgo/djangoContent/django-env/bin/python /home/djgo/djangoContent/icatecd/autocheck.py
# python icatecd/manage.py runserver &
# After=networking.service