import time
import struct
import ulab.numpy as np
import board, busio
import usb_hid, digitalio, analogio
import asyncio, countio
import sys
import random


led = digitalio.DigitalInOut(board.LED)
led.direction = digitalio.Direction.OUTPUT



# global
class m():

    def __init__(self):



        # digital pins
        self.emg_event = 20 # board.GP20
        self.alarm_event = 21 # board.GP21
        self.supply_event = 22 # board.GP22

        self.emg_relay = 9 # board.GP9
        self.alarm_relay = 11 # board.GP11
        
        self.dg_relay = 13 # board.GP13
        self.mains_relay = 15 # board.GP15

        # analog pins
        self.temp_a = 80 # board.A0
        self.pscal_a_after = 81 # board.A1
        self.pscal_a_before = 82 # board.A2

m = m()

recByte = None
idleByte = True


# /global

def toggle_led25(d: float):
    if led.value:
        led.value = 0
        time.sleep(0.100 + d)
    else:
        led.value = 1
        time.sleep(d)

def blink_led25(n=4, d=0.050):
    for i in range(0, n):
        toggle_led25(d)
    time.sleep(1.200)

def get_voltage(raw):
    return (raw * 3300) / 65536


class makeMessage():
    def __init__(self) -> None:

        self.uart0 = busio.UART(board.GP0, board.GP1, baudrate=115200, timeout=3)

        self.full_bypass = 91
        self.exhaust_bypass = 92
        self.partial_bypass = 93

        self.not_ok = 99
        self.ok = 100

        self.log = 110
        self.show = 120
        self.reply = 130
        self.respond_me = 140

        self.val_analog = 191
        self.val_digital = 192

        self.run_status = 200

        self.emergency = 210
        self.disconnect = 220
        self.relay_input = 230
        self.bypass = 240

        self.full_bypass = 211
        self.exhaust_bypass = 212
        self.partial_bypass = 213





    def procRawMsg(self, tbs: list(int)):
        # for n, byt in enumerate(self.genReply(self._exmin)):
        #     self._resp[(n+1)*self.cmByte] = byt
        print("about_to_send >> digital ", tbs)
        st = struct.pack('8B', tbs[0], tbs[1], tbs[2], tbs[3], tbs[4], tbs[5], tbs[6], tbs[7]) # 110.11._._ -> reply.run_status.val.response_req
        return st

    def procAnalogValue(self, containAvg):

        threePair = {
            "temp_a" : None,
            "pscal_a" : None,
            "pscal_b" : None,
        }
        for key in containAvg:
            value = containAvg[key]

            hxstr = hex(value)[2:]
            twoByte = None
            if value > 255:
                if len(hxstr) == 4:
                    stseq = [ int(hxstr[p], 16)*16 if p%2 == 0 else int(hxstr[p], 16) for p in range(len(hxstr)) ]
                    twoByte = [(stseq[0] + stseq[1]), (stseq[2] + stseq[3])]
                    # st = struct.pack('4B', 255, 255, (stseq[0] + stseq[1]), (stseq[2] + stseq[3]))



                elif len(hxstr) == 3:
                    stseq = [ int(hxstr[p], 16) if p%2 == 0 else int(hxstr[p], 16)*16 for p in range(len(hxstr)) ]
                    twoByte = [(stseq[0]), (stseq[1] + stseq[2])]
                    # st = struct.pack('4B', 255, 255, stseq[0], (stseq[1] + stseq[2]))


            else:
                if len(hxstr) == 2:
                    stseq = [ int(hxstr[p], 16)*16 if p%2 == 0 else int(hxstr[p], 16) for p in range(len(hxstr)) ]
                    twoByte = [0, (stseq[0] + stseq[1])]
                    # st = struct.pack('4B', 255, 255, 0, (stseq[0] + stseq[1]))


                elif len(hxstr) == 1:
                    # print("hxstr - ", hxstr, " : l= ", len(hxstr))
                    stseq = [ int(hxstr[p], 16) if p%2 == 0 else int(hxstr[p], 16)*16 for p in range(len(hxstr)) ]
                    twoByte = [0, stseq[0]]
                    # st = struct.pack('4B', 255, 255, 0, stseq[0])

            if twoByte:
                threePair[key] = twoByte

        # after for-loop fills threePair
        if not None in threePair.values():
            print("about_to_send >> analog - ", containAvg)
            st = struct.pack('8B', self.show, self.val_analog,
                            threePair["temp_a"][0], threePair["temp_a"][1],
                            threePair["pscal_a"][0], threePair["pscal_a"][1],
                            threePair["pscal_b"][0], threePair["pscal_b"][1])
            return st




    def sendMsgSerial(self, st):
        self.uart0.write(st)

    def sendValueSerial(self, st):
        self.uart0.write(st)

    # def genDebug(self):
    #     tbs = [self._resp[(n+1)*self.cmByte] for n in range(4)]
    #     print(self._nomen[tbs[0]], " ~ ", self._nomen[tbs[1]], " ~ ", self._nomen[tbs[2]], " ~ ", self._nomen[tbs[3]])
# _._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._.


class monitorDevice():
    def __init__(self) -> None:


        self.adco = analogio.AnalogIn(board.A0)
        self.adc1 = analogio.AnalogIn(board.A1)
        self.adc2 = analogio.AnalogIn(board.A2)

        self.first = 0
        self.turn = 0

        self.outMin = { # 0mV
            "temp_a" : 25,
            "pscal_a" : 2,
            "pscal_b" : 2,
        }
        self.outMax = { # 3300mV
            "temp_a" : 998,
            "pscal_a" : 22100,
            "pscal_b" : 22100,
        }
        self.tNoise = 0
        self.pNoise = 0

        self.outSpan = {
            "temp_a" : self.outMax["temp_a"] - self.outMin["temp_a"],
            "pscal_a" : self.outMax["pscal_a"] - self.outMin["pscal_a"],
            "pscal_b" : self.outMax["pscal_b"] - self.outMin["pscal_b"],
        }
        self.dgSet = {
            "running" : False,
            "bypass" : False,
            "overTemp" : None,
            "overPress" : None,
        }
        self.partial_temps = 214
        self.partial_press = 215

        self._cSetPoints = {
            self.partial_temps : [80, 190, 280, 400, 500, 570],
            self.partial_press : [1000, 1400, 1800, 2900, 4500, 6400]
        }


        # helper class
        self.mmg = makeMessage()
        # /helper class

        
        self.gpio = 0
        self.ucount = 1
        self.uflag = 2



        global m
        
        self.tpin = {
            m.emg_relay : [digitalio.DigitalInOut(board.GP9), None, True],
            m.alarm_relay : [digitalio.DigitalInOut(board.GP11), None, True],
        }
        
        self.upin = {
            m.dg_relay : [board.GP13, None, True],
            m.mains_relay : [board.GP15, None, True],
        }
        


        self.vpin = {
            m.temp_a : [board.A0, None, False],
            m.pscal_a_after : [board.A1, None, False],
            m.pscal_a_before : [board.A2, None, False]
        }

        self.cpin = {
            m.emg_event : [digitalio.DigitalInOut(board.GP20), None, False],
            m.alarm_event : [digitalio.DigitalInOut(board.GP21), None, False],
        }

        self.makeInputs()
        self.makeOutputs()
        self.uarr = [[p, self.upin[p][2]] for p in self.upin.keys()]
        self.varr = [[p, self.vpin[p][2]] for p in self.vpin.keys()]
        self.carr = [[p, self.cpin[p][2]] for p in self.cpin.keys()]

        self.inTask_feedbackRead = None
        self.inTask_adcRead = None
        self.inTask_monitorIdle = None
        self.tasks = [
            self.inTask_adcRead,
            self.inTask_feedbackRead,
            self.inTask_monitorIdle
        ]
        # self.inTask_emgStop,
        # self.inTask_alarmEvent,

        # self.inTask_emgRelay,
        # self.inTask_alarmRelay,
        # self.inTask_dgRelay,
        # self.inTask_mainsRelay,

        # self.inTask_adcRead,
        # directions

    # coroutines on digital inputs

    async def catchValues(self):
        while True:
            if self.turn == 0:
                # asyncio.wait_for(self.inTask_feedbackRead, 2)
                
                contain_avg = {
                    "temp_a" : None,
                    "pscal_a" : None,
                    "pscal_b" : None,
                }

                contain_temp_a = []
                for i in range(10):
                    raw = self.adco.value
                    time.sleep(0.050)
                    contain_temp_a.append(raw)
                # contain_temp_a.sort(reverse=True)

                

                if self.tNoise == 0:
                    self.tNoise = int(self.getAvgOf(contain_temp_a)) #
                else:
                    self.tNoise = int((self.tNoise + self.getAvgOf(contain_temp_a))/2)


                contain_avg["temp_a"] = self.tNoise

                contain_pscal_a = []
                for i in range(10):
                    raw = self.adc1.value
                    time.sleep(0.050)
                    contain_pscal_a.append(raw)

                contain_avg["pscal_a"] = self.getAvgOf(contain_pscal_a)
                
                contain_pscal_b = []
                for i in range(10):
                    raw = self.adc2.value
                    time.sleep(0.050)
                    contain_pscal_b.append(raw)

                # contain_avg["pscal_b"] = self.getAvgOf(contain_pscal_b)
                if self.pNoise == 0:
                    self.pNoise = int(self.getAvgOf(contain_pscal_b)) #
                else:
                    self.pNoise = int((self.pNoise + self.getAvgOf(contain_pscal_b))/2)


                contain_avg["pscal_b"] = self.pNoise



                if self.upin[m.dg_relay][self.uflag] is False:

                    values = contain_avg.copy()
                    for key in values.keys():
                        valueScaled = float(values[key] / 65535)
                        valueMapped = int(self.outMin[key] + (valueScaled * self.outSpan[key]))
                        values[key] = valueMapped


                    if values["temp_a"] < self._cSetPoints[self.partial_temps][0]:
                        if values["pscal_b"] in range(values["pscal_a"]-250, values["pscal_a"]+250):
                            self.dgSet["bypass"] = True

                        else:
                            self.dgSet["bypass"] = False


                    elif values["temp_a"] > self._cSetPoints[self.partial_temps][0]:

                        if values["pscal_b"] in range(values["pscal_a"]-250, values["pscal_a"]+250):
                            self.dgSet["bypass"] = True

                        else:
                            self.dgSet["bypass"] = False

                        if values["temp_a"] < self._cSetPoints[self.partial_temps][1]:
                            if values["pscal_b"] - values["pscal_a"] < self._cSetPoints[self.partial_press][1]:
                                self.dgSet["bypass"] = True
                        elif values["temp_a"] < self._cSetPoints[self.partial_temps][2]:
                            if values["pscal_b"] - values["pscal_a"] < self._cSetPoints[self.partial_press][2]:
                                self.dgSet["bypass"] = True
                        elif values["temp_a"] < self._cSetPoints[self.partial_temps][3]:
                            if values["pscal_b"] - values["pscal_a"] < self._cSetPoints[self.partial_press][3]:
                                self.dgSet["bypass"] = True
                        elif values["temp_a"] < self._cSetPoints[self.partial_temps][4]:
                            if values["pscal_b"] - values["pscal_a"] < self._cSetPoints[self.partial_press][4]:
                                self.dgSet["bypass"] = True
                        elif values["temp_a"] < self._cSetPoints[self.partial_temps][5]:
                            if values["pscal_b"] - values["pscal_a"] < self._cSetPoints[self.partial_press][5]:
                                self.dgSet["bypass"] = True

                        else:
                            self.dgSet["bypass"] = False # means all OEM and DOFF limits goooood


                if not None in contain_avg.values():
                    st = self.mmg.procAnalogValue(contain_avg)
                    # print(contain_avg, " == ", st)
                    self.mmg.sendValueSerial(st)
                    self.turn = 1
                    time.sleep(0.200)

            ## ______________________________________________________________________________________________________________
            ## ______________________________________________________________________________________________________________
            
            elif self.turn == 1:
                # asyncio.wait_for(self.inTask_adcRead, 2)
                
                # print(" running catchDigEvent `oo` ")
                
                # flags = self.getStates() # not applicable here because bypassing is needed

                for ic in self.upin.keys():
                    if self.upin[ic][self.uflag] == False:
                        if isinstance(self.upin[ic][self.ucount], countio.Counter):
                            
                            i = self.upin[ic][self.ucount].count
                            if i > 0:

                                self.upin[ic][self.uflag] = True
                                # print(self.upin)
                                self.upin[ic][self.ucount].reset()
                                self.fillCounter(fault, restrict=True)

                    elif self.upin[ic][self.uflag]:
                        ## count10 -- digital10
                        
                        di = self.upin[ic][self.ucount]

                        if isinstance(di, digitalio.DigitalInOut):
                            if di.value == 0:
                                self.fillCounter(ic)
                                # print(" corrected ? -> Yes ")
                                self.upin[ic][self.uflag] = False
                                pass

                            elif di.value == 1:
                                # self.upin[fault][self.uflag] = True
                                # print(" corrected ? -> Nooo ")
                                pass
                
                
                if self.cpin[m.emg_event][self.uflag]:
                    if self.tpin[m.emg_relay][self.gpio].value == 1:
                        self.tpin[m.emg_relay][self.uflag] = True
                    elif self.tpin[m.emg_relay][self.gpio].value == 0:
                        self.tpin[m.emg_relay][self.uflag] = False
                elif not self.cpin[m.emg_event][self.uflag]:
                    self.tpin[m.emg_relay][self.uflag] = False
                    
                if self.cpin[m.alarm_event][self.uflag]:
                    if self.tpin[m.alarm_relay][self.gpio].value == 1:
                        self.tpin[m.alarm_relay][self.uflag] = True
                    elif self.tpin[m.alarm_relay][self.gpio].value == 0:
                        self.tpin[m.alarm_relay][self.uflag] = False
                elif not self.cpin[m.alarm_event][self.uflag]:
                    self.tpin[m.alarm_relay][self.uflag] = False
                
                                
                faults = self.getStates()
                seq=[self.mmg.run_status, self.mmg.relay_input, 0, 0, 0, 0, self.mmg.respond_me, self.mmg.not_ok]
                indexer = [m.emg_relay, m.alarm_relay, m.dg_relay, m.mains_relay]
                if len(faults) > 0:
                    for fault in faults:
                        # print("pick which gpio trigger", fault)
                        seq[(indexer.index(fault)+2)] = fault
                elif len(faults) == 0:
                    seq[-1] = self.mmg.ok  

                # print(seq)
                st = self.mmg.procRawMsg(tbs=seq)
                self.mmg.sendMsgSerial(st)
                self.turn = 0
                time.sleep(0.200)

            # await asyncio.sleep(2000) # coroutine gave up control

            await asyncio.sleep_ms(1500)




    async def monitorIdle(self):
        global m
        
        while True: # self.inTask_catchValues.done():
            # print(" running monitorIdle `oo` ")
            
            if self.dgSet["bypass"] is True:
                self.cpin[m.emg_event][self.uflag] = False
            elif self.dgSet["bypass"] is False:
                self.cpin[m.emg_event][self.uflag] = False
                
            if self.tpin[m.emg_relay][self.uflag]:
                self.cpin[m.alarm_event][self.uflag] = True
            if self.tpin[m.alarm_relay][self.uflag]:
                self.cpin[m.alarm_event][self.uflag] = True
            
            await asyncio.sleep_ms(1500)


    async def throwFaultEvent(self):
        global m
        while True:
            asyncio.wait_for(self.inTask_monitorIdle, 2)
            
            # faults = self.getStates()

            if self.cpin[m.emg_event][self.uflag]:
                self.cpin[m.emg_event][self.gpio].value = 0
            elif self.cpin[m.emg_event][self.uflag] == False:
                self.cpin[m.emg_event][self.gpio].value = 1
                    
            if self.cpin[m.alarm_event][self.uflag]:
                self.cpin[m.alarm_event][self.gpio].value = 0
            elif self.cpin[m.alarm_event][self.uflag] == False:
                self.cpin[m.alarm_event][self.gpio].value = 1

            await asyncio.sleep_ms(1000)






    async def createTasks(self): # defined async because you can't call an 'async' fxn directly from a non-async code
        # create_task wraps the coroutine in a Task
        # uTasks = [] # pass using * unpack to gather
        global m

        self.inTask_throwFaultEvent = asyncio.create_task(self.throwFaultEvent())
        self.inTask_valueRead = asyncio.create_task(self.catchValues())
        self.inTask_monitorIdle = asyncio.create_task(self.monitorIdle())
        returned = asyncio.gather(
            self.inTask_monitorIdle,
            self.inTask_valueRead,
            self.inTask_throwFaultEvent
        )
        await returned


    def getStates(self):
        self.uarr = [[p, self.upin[p][2]] for p in self.upin.keys()]
        uflags = np.array(self.uarr, dtype=np.uint8)
        self.tarr = [[p, self.tpin[p][2]] for p in self.tpin.keys()]
        tflags = np.array(self.tarr, dtype=np.uint8)
        
        trueFlags = []
        if np.any(uflags[:,1]):
            for n, check in enumerate(uflags[:,1]):
                if check == 1:
                    trueFlags.append(uflags[n,0])
                  
        if np.any(tflags[:,1]):
            for n, check in enumerate(tflags[:,1]):
                if check == 1:
                    trueFlags.append(tflags[n,0])
        
        return trueFlags


    def getEnvironment(self):
        if self.first == 0:
            levels = []
            for gpio in self.upin.keys():
                self.fillCounter(gpio, restrict=True)
                di = self.upin[gpio][self.ucount]
                levels.append([gpio, di.value])

            levels = np.array(levels, dtype=np.uint8)

            if np.any(levels[:,1]):
                for i, pinFlag in enumerate(levels[:,1]):
                    if pinFlag == 1:
                        self.upin[levels[i,0]][self.uflag] = True
                    elif pinFlag == 0:
                        self.upin[levels[i,0]][self.uflag] = False

            for di in self.upin.keys():
                if self.upin[di][self.uflag] == False:
                    self.fillCounter(di)

            print(" made environment >> ")
            self.first = 1
            return True
        else:
            return False




    def fillCounter(self, di, restrict=False, event=countio.Edge.RISE, hold=digitalio.Pull.UP):
        if restrict:
            if self.upin[di][self.ucount] is None: # for initial checks
                self.upin[di][self.ucount] = digitalio.DigitalInOut(self.upin[di][self.gpio])
                dio = self.upin[di][self.ucount]
                dio.direction = digitalio.Direction.INPUT
                dio.pull = digitalio.Pull.UP


            if not isinstance(self.upin[di][self.ucount], int):
                if self.upin[di][self.ucount] is not None:
                    self.upin[di][self.ucount].deinit()
                    self.upin[di][self.ucount] = None
                    self.upin[di][self.ucount] = digitalio.DigitalInOut(self.upin[di][self.gpio])
                    dio = self.upin[di][self.ucount]
                    dio.direction = digitalio.Direction.INPUT
                    dio.pull = digitalio.Pull.UP

        elif not restrict:
            self.upin[di][self.ucount].deinit()
            icount = countio.Counter(pin=self.upin[di][self.gpio], edge=event, pull=hold)
            self.upin[di][self.ucount] = icount



    def runMonitor(self):
        if self.getEnvironment():
            print("done initial assessment >> ")
            asyncio.run(self.createTasks()) # wherever
        # loop = asyncio.get_event_loop()
        # loop.run_until_complete(self.monitorIdle)


    def makeOutputs(self):
        for do in self.cpin.keys():
            self.cpin[do][self.gpio].direction = digitalio.Direction.OUTPUT
            
    def makeInputs(self):
        for di in self.tpin.keys():
            
            self.tpin[di][self.gpio].direction = digitalio.Direction.INPUT
            self.tpin[di][self.gpio].pull = digitalio.Pull.UP


    def getAvgOf(self, val_list):
        vals = list(filter(lambda rv: rv > 10 , val_list))
        try:
            avgVal = sum(vals) / float(len(vals))
            return int(avgVal)
        except ZeroDivisionError as odiv:
            return 0
# _._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._._.

blink_led25()
mdc = monitorDevice()
mdc.runMonitor()