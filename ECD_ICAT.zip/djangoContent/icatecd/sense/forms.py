import datetime
from django import forms
from sense.models import LogDetail, ErrorCode
from sense.models import _operator, _part

class LogDetailForm(forms.ModelForm):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["created"].widget = forms.TextInput()
        self.fields["modified"].widget = forms.TextInput()

        now = datetime.datetime.now()
        self.fields["created"].initial = now
        self.fields["modified"].initial = now
        # self.fields["created"].input_formats = ['']
        # self.fields["modified"].input_formats = ['']



    created = forms.DateTimeField(input_formats=['%d-%m-%Y %H:%M'])
    modified = forms.DateTimeField(input_formats=['%d-%m-%Y %H:%M'])
    title = forms.CharField(strip=True, required=True, max_length=32)
    part = forms.ChoiceField(choices=_part)
    note = forms.Textarea() # JSONField()
    ecode = forms.ModelChoiceField(queryset=ErrorCode.objects.all())
    operator = forms.ChoiceField(required=True, choices=_operator)
    resolved = forms.BooleanField()


    class Meta:
        model = LogDetail
        fields = "__all__" # ['created', 'modified', 'title', 'part', 'note', 'ecode', 'operator', 'pending']
        # widgets = { 'part' : forms.Select(attrs={'class': "form-select select-log_part"}),}