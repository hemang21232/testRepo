import serial as SERIAL
from sense.cmdserial import cmd

class Talker:
    TERMINATOR = '\r'.encode('UTF8')

    def __init__(self):
        self.mSerial = None
    
    def open(self, tout=5):
        if self.mSerial is None:
            self.mSerial = SERIAL.Serial(
                port = "/dev/ttyS0",
                baudrate = 115200,
                parity = SERIAL.PARITY_NONE,
                stopbits = SERIAL.STOPBITS_ONE,
                bytesize = SERIAL.EIGHTBITS,
                timeout = tout
            )
            print("ttyS0 => OPEN")
        else:
            pass
        
        

    def send(self, text: str):
        line = '%s\r\f' % text
        self.mSerial.write(line.encode('utf-8'))
        # reply = self.receive()
        # reply = reply.replace('>>> ', "")
        # if reply != text:
        #     raise ValueError('expected %s got %s' % (text, reply))

    def receive(self, qt=8):
        # line = self.mSerial.read_until(self.TERMINATOR)
        # return line.decode('UTF8').strip()
        
        
        while True:
                # continue # pass
            
            if self.mSerial.in_waiting == qt:
                # print(" - in waiting ", self.mSerial.in_waiting)    
                rd = self.mSerial.read(qt) # mSerial.read_until() 

                v_o = bytearray(rd)
                if len(v_o) == 8:
                    # print("rf pico(serial) > ", v_o)
                    
                    self.mSerial.flushInput() # .reset_input_buffer()
                    return v_o
                else:
                    continue


            else:
                # print(" - in waiting ", self.mSerial.in_waiting)
                # timeout += 1
                # if timeout > 10:
                #     print("serial_in waiting timeout")
                #     break

                continue
        
        
            

    def close(self):
        self.mSerial.close()

"""
if v_o[0] == cmd.run_status:
                        if v_o[1] == cmd.relay_input:
                            if v_o[5] == cmd.mains_relay:
                                noise += 1
                                if noise > 2:

"""