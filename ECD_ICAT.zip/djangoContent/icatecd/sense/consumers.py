import json
from asgiref.sync import sync_to_async, async_to_sync
from sense import tasks
from sense.ioserial import Talker
from channels.generic.websocket import AsyncJsonWebsocketConsumer
from sense.cmdserial import cmd




class StatusConsumer(AsyncJsonWebsocketConsumer):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.switch = True
  
        self.tk = Talker()
        print("consumer created")

    async def connect(self):
        self.group_name = 'dashboard'
        # Join room group
        
        await self.channel_layer.group_add(
            self.group_name,
            self.channel_name # parent variable
        )
        await self.accept()

    async def disconnect(self, close_code):
        
        await self.channel_layer.group_discard(
            self.group_name,
            self.channel_name
        )

    # async def receive(self, text_data):

        """
        Receive message from WebSocket.
        Get the event and send the appropriate event
        """

    async def receive_json(self, jsobj, **kwargs):
        # return await super().receive_json(content, **kwargs)

        qt = jsobj['valueNext']
        # print("received jsobj >> ", jsobj)
        self.tk.open()
        content = {}
        activeTab = jsobj['activeTab']

        if qt == 8:
            # print("activeTab -> ", activeTab)
            v_i = self.tk.receive(qt=qt)
            # print("# pass", v_i)
            if isinstance(v_i, bytearray):
                
                    
                if cmd.needsAction(v_i):
                    # await cmd.callActionRedirect()
                    pass
                    
                                    
                if activeTab == "logs":
                    # print("if activeTab == logs:")
                    if jsobj['fetch']:
                        content["logData"] = await cmd.fetchAllLogs()
                        content["activeTab"] = activeTab
                        await self.sendData(content)
                    else :
                        content["activeTab"] = activeTab
                        await self.sendData(content)
                    # print("showLogs >> content ", content, " TYPE = ", type(content))

                elif activeTab == "menu":
                    # print("if activeTab == menu:")
                    # pass
                    content["activeTab"] = activeTab
                    await self.sendData(content)
                    # print("showMenu >> content ", content, " TYPE = ", type(content))

                elif activeTab == "dash":
                    # print("elif activeTab == dash:")
                    if v_i[0] == cmd.run_status:
                        if v_i[1] == cmd.relay_input:
                            values = {
                                "emg_relay" : v_i[2],
                                "dg_relay" :  v_i[3],
                                "alarm_relay" : v_i[4],
                                "mains_relay" : v_i[5]
                            }
                            content["values"] = values
                            content["valueAnalog"] = False
                            content["valueFeedback"] = True
                            # self.tk.close()

                            # print("channel -> show  ", content)
                            # print("consumer > receive_json : try ")
                            content["activeTab"] = activeTab
                            await self.sendData(content)

                            
                    
                    if v_i[0] == cmd.show:
                        if v_i[1] == cmd.val_analog:
                            values = cmd.scaleValues(v_i)
                            
                            content["values"] = values
                            content["abnormal"] = {
                                "bypass" : cmd.dgSet["bypass"]
                            }


                            content["valueAnalog"] = True
                            content["valueFeedback"] = False
                            # self.tk.close()

                            # print("consumer > receive_json : try ")
                            # print("channel -> show  ", content)
                            content["activeTab"] = activeTab
                            await self.sendData(content)
                
                



    async def sendData(self, event=None):
        
        # print("consumer > sendData : try ", event)
        await self.send_json(content=event)
   
"""
    def translate(value, inMin, inMax, outMin, outMax):

        inSpan = inMax - inMin
        outSpan = outMax - outMin

        valueScaled = float(value - inMin) / float(inSpan)
        outMin + (valueScaled * outSpan)
"""