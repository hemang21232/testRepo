from django.db import models
from sense.cmdserial import cmd
from django.utils import timezone

_priority = (
    ('IM', "Immediate"),
    ('WD', "Working Day"),
    ('WW', "Working Week"),
)

_operator = (
        ('CLIENT', "Client"),
        ('CHAKR', "CHAKR"),
    )

_part = (
        (cmd.emg_relay, "Emg Relay"),
        (cmd.dg_relay, "DG Relay"),
        (cmd.alarm_relay, "Alarm Relay"),
        (cmd.mains_relay, "Mains Relay"),
        (cmd.temp_a, "Temp A"),
        (cmd.pscal_a_before, "kPA Before"),
        (cmd.pscal_a_after, "kPA After"),
    )


class ErrorCode(models.Model):
    event = models.TextField(blank=False, unique=True)
    detail = models.IntegerField(blank=True, unique=False, choices=_part)
    priority = models.CharField(blank=False, unique=False, choices=_priority, max_length=2)


class LogDetail(models.Model):
    
    created = models.DateTimeField(auto_now=True)
    title = models.CharField(blank=False, null=False, max_length=32)
    part = models.IntegerField(choices=_part)
    note = models.TextField(blank=True)
    ecode = models.ForeignKey(ErrorCode, on_delete=models.CASCADE)
    operator = models.CharField(blank=False, choices=_operator, max_length=32)
    resolved = models.BooleanField(default = True)

    def save(self, *args, **kwargs):
        if not self.id:
            self.created = timezone.now()
        return super(LogDetail, self).save(*args, **kwargs)

    class Meta:
        db_table = "log_detail"

    

"""
        

"""