from django.urls import path
from sense.views import getRealTime, putLog, updateLog, deleteLog, showLogs, clearLogs


urlpatterns = [
    path('dashboard/<str:room_code>/', getRealTime),
    # path('qwerty/', getRealTime),
    path('log/', putLog),
    path('edit-log/', updateLog),
    path('delete-log/', deleteLog),
    path('show/', showLogs, name="show"),
    path('clear-logs/', clearLogs),
]



    # path('', testSerial, name='uart_tx'),
    # path('rec/', getSerial),