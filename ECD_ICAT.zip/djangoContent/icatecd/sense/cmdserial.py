from sense import models
from asgiref.sync import sync_to_async
from django.forms.models import model_to_dict
from django.core import serializers
import json

class Commander:

    def __init__(self) -> None:


        self.cmByte = 1001
        self.sbcmByte = 2002
        self.valh = 7007
        self.vall = 8008

        self.filter = 10

        self.emg_event = 20
        self.alarm_event = 21

        self.emg_relay = 9
        self.alarm_relay = 11
        self.dg_relay = 13
        self.mains_relay = 15

        self.exmin = {
            self.emg_relay : None,
            self.dg_relay : None,
            self.alarm_relay : None,
            self.mains_relay : None
        }
        
        self.temp_a = 80
        self.pscal_a_after = 81
        self.pscal_a_before = 82
        
        self.partial_temps = 214
        self.partial_press = 215
        
        self.outMin = { # 0mV
            "temp_a" : 25,
            "pscal_a" : 2,
            "pscal_b" : 2,
        }
        self.outMax = { # 3300mV
            "temp_a" : 998,
            "pscal_a" : 22100,
            "pscal_b" : 22100,
        }
        
        self.inSpan = 65535 # self.inMax - self.inMin
        self.outSpan = {
            "temp_a" : self.outMax["temp_a"] - self.outMin["temp_a"],
            "pscal_a" : self.outMax["pscal_a"] - self.outMin["pscal_a"],
            "pscal_b" : self.outMax["pscal_b"] - self.outMin["pscal_b"],
        }
        
        self.full_bypass = 91
        self.exhaust_bypass = 92
        self.partial_bypass = 93

        self.over_temp = 94
        self.over_press = 95
        
        

        self.not_ok = 99
        self.ok = 100
        self.dgOff = 101

        self.log = 110
        self.show = 120
        
        self.val_analog = 191
        self.val_digital = 192

        self.run_status = 200

        self.emergency = 210
        self.disconnect = 220
        self.relay_input = 230
        self.bypass = 240

        self.prevent = {
            self.emg_relay : False,
            self.dg_relay : False,
            self.alarm_relay : False,
            self.mains_relay : False,
            self.full_bypass : False,
            self.partial_bypass : False,
            self.exhaust_bypass : False,
            self.over_temp : False,
            self.over_press : False,
            self.dgOff : False,
            self.ok : False,
        }
        
        self.dgSet = {
            "running" : True, # so that checkBypass is triggered anyhow (aBUG)
            "abnormal" : False,
            "bypass" : self.ok,
            "overTemp" : None,
            "overPress" : None,
            "fault" : False,
            "faulty" : {
                self.emg_relay : False,
                self.dg_relay : False,
                self.alarm_relay : False,
                self.mains_relay : False
            }
        }
        # partial bypass paramets get set point values

        self._cSetPoints = { 
            self.partial_temps : [80, 190, 280, 400, 500, 570, 700],
            self.partial_press : [1000, 1400, 1800, 2900, 4500, 6400, 7500]
        }

        

    def scaleValues(self, v_i):
        values = {
            "temp_a" : (v_i[2] * 256) + v_i[3],
            "pscal_a" : (v_i[4] * 256) + v_i[5],
            "pscal_b" : (v_i[6] * 256) + v_i[7],
            }
        for key in values.keys():
            valueScaled = float(values[key] / float(self.inSpan))
            valueMapped = int(self.outMin[key] + (valueScaled * self.outSpan[key]))
            values[key] = valueMapped

        return values

    def putExmin(self, seq):
        # [m.emg_relay = a2, m.dg_relay = b3, m.alarm_relay = c4, m.mains_relay = d5]
        self.exmin[self.emg_relay] = seq[2]
        self.exmin[self.alarm_relay] = seq[3]
        self.exmin[self.dg_relay] = seq[4]
        self.exmin[self.mains_relay] = seq[5]


        
    def emptyExmin(self):
        for key in self.exmin.keys():
            self.exmin[key] = 0
    
    def resetFaulty(self):
        for key in self.dgSet["faulty"].keys():
            self.dgSet["faulty"][key] = False

    def needsAction(self, seq):
        
        if seq[0] == self.run_status:
            if seq[1] == self.relay_input:
                self.putExmin(seq)
                do = self.checkFeedbacks(seq[7])
                # print("checkFeedbacks - do", do)
                return do
                
        elif seq[0] == self.show:
            if seq[1] == self.val_analog:
                values = self.scaleValues(seq)
                do = self.checkBypass(values)
                # print("checkBypass - do", do)
                return do



    def checkFeedbacks(self, lastByt):

        if lastByt == self.not_ok:
            
            if self.exmin[self.mains_relay] > 0:
                
                self.dgSet["fault"] = True
                self.dgSet["faulty"][self.mains_relay] = True
                
                return True
                
            elif self.exmin[self.mains_relay] == 0:
                self.dgSet["faulty"][self.mains_relay] = False
                
                if self.prevent[self.mains_relay] is True:
                    self.prevent[self.mains_relay] = False
                
                for key in self.exmin.keys():
                    if self.exmin[key] > 0:
                        self.dgSet["faulty"][key] = True
                        if key == self.dg_relay:
                            # print("TURNING OFF DG-SET = ")
                            self.dgSet["running"] = False        
                        
                    elif self.exmin[key] == 0:
                        self.dgSet["faulty"][key] = False
                        if self.prevent[key] is True:
                            self.prevent[key] = False
                        if key == self.dg_relay:
                            # print("TURNING ON DG-SET = ")
                            self.dgSet["running"] = True 
                        

                
                # print("def checkFeedbacks -- ", self.dgSet["faulty"])
                if True in self.dgSet["faulty"].values():
                    self.dgSet["fault"] = True
                    return True
                    

                    
            

            
            # if self.exmin[self.mains_relay] == 0:
        
            #     if self.exmin[self.alarm_relay] == 0:
        
            #         if self.exmin[self.dg_relay] == 0:
                        
            #             if self.exmin[self.emg_relay] == 0:
                            
            #                 return False

                

            # returning common
            


        elif lastByt == self.ok:
            self.dgSet["fault"] = False
            if self.dgSet["running"] is False:
                if self.exmin[self.dg_relay] == 0:
                    # print("TURNING ON DG-SET = recover")
                    self.dgSet["running"] = True
            self.resetFaulty()
            return False
                    
    def checkBypass(self, values):
        
        # print("is DG running ? ", self.dgSet["running"])
        if self.dgSet["running"] is True:
            
            if values["temp_a"] < self._cSetPoints[self.partial_temps][0]:
                if values["pscal_b"] in range(values["pscal_a"]-250, values["pscal_a"]+250):
                    self.dgSet["bypass"] = self.exhaust_bypass
                    self.dgSet["abnormal"] = True
                    # print(" debug -> self.dgSet[bypass] = ", self.dgSet["bypass"])
                    return True
                else:
                    self.dgSet["bypass"] = self.ok
                    
            elif values["temp_a"] > self._cSetPoints[self.partial_temps][0]:
                if values["pscal_b"] in range(values["pscal_a"]-250, values["pscal_a"]+250): 
                    self.dgSet["bypass"] = self.full_bypass
                    self.dgSet["abnormal"] = True
                    # print(" debug -> self.dgSet[bypass] = ", self.dgSet["bypass"])
                    return True
                    
                else:
                    self.dgSet["bypass"] = self.ok

                if values["pscal_b"] > self._cSetPoints[self.partial_press][6]:
                    self.dgSet["bypass"] = self.over_press
                    self.dgSet["abnormal"] = True
                    # print(" debug -> self.dgSet[bypass] = ", self.dgSet["bypass"])
                    return True
                    
                else:
                    self.dgSet["bypass"] = self.ok
            
                
                if values["temp_a"] < self._cSetPoints[self.partial_temps][1]:
                    if values["pscal_b"] - values["pscal_a"] < self._cSetPoints[self.partial_press][1]:
                        self.dgSet["bypass"] = self.partial_bypass
                        self.dgSet["abnormal"] = True
                        # print(" debug -> 1 self.dgSet[bypass] = ", self.dgSet["bypass"])
                        return True
                elif values["temp_a"] < self._cSetPoints[self.partial_temps][2]:
                    if values["pscal_b"] - values["pscal_a"] < self._cSetPoints[self.partial_press][2]:
                        self.dgSet["bypass"] = self.partial_bypass
                        self.dgSet["abnormal"] = True
                        # print(" debug -> 2 self.dgSet[bypass] = ", self.dgSet["bypass"])
                        return True
                elif values["temp_a"] < self._cSetPoints[self.partial_temps][3]:
                    if values["pscal_b"] - values["pscal_a"] < self._cSetPoints[self.partial_press][3]:
                        self.dgSet["bypass"] = self.partial_bypass
                        self.dgSet["abnormal"] = True
                        # print(" debug -> 3 self.dgSet[bypass] = ", self.dgSet["bypass"])
                        return True
                elif values["temp_a"] < self._cSetPoints[self.partial_temps][4]:
                    if values["pscal_b"] - values["pscal_a"] < self._cSetPoints[self.partial_press][4]:
                        self.dgSet["bypass"] = self.partial_bypass
                        self.dgSet["abnormal"] = True
                        # print(" debug -> 4 self.dgSet[bypass] = ", self.dgSet["bypass"])
                        return True
                elif values["temp_a"] < self._cSetPoints[self.partial_temps][5]:
                    if values["pscal_b"] - values["pscal_a"] < self._cSetPoints[self.partial_press][5]:
                        self.dgSet["bypass"] = self.partial_bypass
                        self.dgSet["abnormal"] = True
                        # print(" debug -> 5 self.dgSet[bypass] = ", self.dgSet["bypass"])
                        return True
                    
                else:
                    self.dgSet["bypass"] = self.ok
                    # self.dgSet["abnormal"] = False
                    # return False # means all OEM and DOFF limits goooood  

            elif values["temp_a"] > self._cSetPoints[self.partial_temps][6]:
                    self.dgSet["bypass"] = self.over_temp
                    self.dgSet["abnormal"] = True
                    # print(" debug -> self.dgSet[bypass] = ", self.dgSet["bypass"])
                    return True
                    
        
            
            if self.dgSet["bypass"] == self.ok:
                self.dgSet["abnormal"] = False
                return False

        else:
            if self.prevent[self.dgSet["bypass"]] is True:
                self.prevent[self.dgSet["bypass"]] = False
            self.dgSet["bypass"] = self.dgOff
            self.dgSet["abnormal"] = False
            return False
        



    


    @sync_to_async
    def callActionRedirect(self):
        if self.dgSet["fault"] is True:
            
            # print("callActionRedirect << fault")
            
            
            if self.dgSet["faulty"][self.mains_relay] == True:
                if self.prevent[self.mains_relay] is False:
                    # print("should ignore prevent TRUES -> ", self.prevent[self.mains_relay])
                    # ec = models.ErrorCode.objects.filter(sequence=sn_fkey)
                    # ec_fkey = ec.values()[0]['id']
                    # print("ec.pk - ", ec_fkey)
                    ec_model = models.ErrorCode.objects.get(detail=self.mains_relay)
                    # print(ec_model.event)

                    ld = models.LogDetail()
                    ld.title = "Mains_Supply / Relay"
                    ld.part = self.mains_relay
                    ld.note = "Check Mains AC Input Supply voltage / relay"
                    ld.ecode = ec_model
                    ld.operator = "CHAKR"
                    ld.resolved = False

                    ld.save()
                    self.prevent[self.mains_relay] = self.dgSet["faulty"][self.mains_relay]
                    print("sense > callActionRedirect > log mains_relay")
                    
                    self.emptyExmin()
                    
                    
            elif self.dgSet["faulty"][self.mains_relay] == False:
                for key in self.exmin.keys():
                    if self.dgSet["faulty"][key] == True:
                        
                        if self.prevent[key] == False:
                            print("should ignore prevent TRUES -> ", self.prevent[key], key)
                            
                            ec_model = models.ErrorCode.objects.get(detail=key)
                            # print(ec_model.event)
                            ld = models.LogDetail()
                            ld.title = "Component / Relay Failure"
                            
                            ld.part = key
                            ld.note = f"Check component / relay (see ErrorCode)"
                            ld.ecode = ec_model
                            ld.operator = "CHAKR"
                            ld.resolved = False

                            ld.save()
                            self.prevent[key] = True # self.dgSet["faulty"][key]
                            print("sense > callActionRedirect > log other_relays")
                            
                self.emptyExmin()
                
                

        if self.dgSet["abnormal"] is True:
            # print("callActionRedirect << abnormal", self.prevent)
            if self.dgSet["bypass"] == self.full_bypass:
                if self.prevent[self.full_bypass] is False:
                    ec_model = models.ErrorCode.objects.get(detail=self.full_bypass)
                    # print(ec_model.event)

                    ld = models.LogDetail()
                    ld.title = "Bypass / Abnormal"
                    ld.part = self.filter
                    ld.note = "Check If you forgot the Filter. Stop Polluting"
                    ld.ecode = ec_model
                    ld.operator = "CHAKR"
                    ld.resolved = False

                    ld.save()
                    # print("sense > callActionRedirect > log bypass")
                    self.prevent[self.full_bypass] = True
                else:
                    pass

            elif self.dgSet["bypass"] == self.over_press:
                if self.prevent[self.over_press] is False:
                    ec_model = models.ErrorCode.objects.get(detail=self.over_press)
                    # print(ec_model.event)

                    ld = models.LogDetail()
                    ld.title = "OverPressure / Warning"
                    ld.part = self.filter
                    ld.note = "Clean the Filter. DG might burst"
                    ld.ecode = ec_model
                    ld.operator = "CHAKR"
                    ld.resolved = False

                    ld.save()
                    # print("sense > callActionRedirect > log overpress")
                    self.prevent[self.over_press] = True
                else:
                    pass

            elif self.dgSet["bypass"] == self.over_temp:
                if self.prevent[self.over_temp] is False:
                    ec_model = models.ErrorCode.objects.get(detail=self.over_temp)
                    # print(ec_model.event)

                    ld = models.LogDetail()
                    ld.title = "OverTemperature / Warning"
                    ld.part = self.filter
                    ld.note = "Drop the load. Engine will melt down"
                    ld.ecode = ec_model
                    ld.operator = "CHAKR"
                    ld.resolved = False

                    ld.save()
                    # print("sense > callActionRedirect > log overtemp")
                    self.prevent[self.over_temp] = True
                else:
                    pass


                

        


    @sync_to_async
    def fetchAllLogs(self):
        logs = models.LogDetail.objects.all()
        errors = models.ErrorCode.objects.all().values_list()

        
        codes = {}
        for ecode in errors:
            codes[ecode[0]] = ecode[1]

        count = [c for c in range(logs.count())]

        # codes_js = serializers.serialize('json', codes) # no attribute _meta
        logs_js = serializers.serialize('json', logs)
        codes_js = json.dumps(codes)
        content = {
            "logs" : logs_js,
            "codes" : codes_js,
            "count": count
        }
        return content

        

cmd = Commander()

