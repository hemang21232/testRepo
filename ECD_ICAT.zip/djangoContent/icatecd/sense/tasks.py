import random
from channels.layers import get_channel_layer
from asgiref.sync import sync_to_async, async_to_sync
from icatecd.celery import app

from sense.ioserial import Talker
from sense.cmdserial import Commander


tk = Talker()
cmd = Commander()

layer = get_channel_layer()


class SerialTask():

    def __init__(self) -> None:
        self.running = False

    @app.task # (name='judge_serial_command')
    def judgeSerialCommand(self, content):
        
        self.running = True
        global tk

        
        ib = tk.receive()
        v_o = bytearray(ib)

        
        content = {
                'valueNext': v_o[0],
                'valueTag': v_o[2]
            }

        tk.close()
        


        self.running = False
