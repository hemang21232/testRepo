import json
from django.shortcuts import render, redirect, HttpResponseRedirect
from sense import tasks
from sense.models import LogDetail
from sense.forms import LogDetailForm # , LogEntryForm




"""
def testSerial(request):
    if request.method == "POST":
        v_in = request.POST['tx_num']
        print("sense > views : " + v_in)
        judgeSerialCommand.delay()
        v_in = str(v_in)
        return redirect('/serial/rec?&vin=%s' % (v_in))
    return render(request, 'sense/send.html', {})

def getSerial(request):
    valueIn = request.GET.get("vin")
    res = Sense.objects.filter(vin=valueIn).values()
    print("sense > views : res", end="")
    print(res)
    context = {
        'value_in': res[0]["vin"],
        'value_out': res[0]["vout"]
    }
    return render(request, 'sense/receive.html', context)
"""

def getRealTime(request, room_code):
    return render(request, 'sense/realtime.html')
    # redirect to "realtime.html"

    # return redirect('/gpio/%s?&character=%s' % (room_code, char_choice))

def putLog(request):
    if request.method == "POST":
        article = LogDetailForm(request.POST) # create form to change an existing article
        # print(article.__dict__.keys())
        try:
            if article.is_valid():
                article.save()
                print(article.fields.keys())
                return redirect('show') # return HttpResponseRedirect('/show')
            else:
                print("sense > views > is_valid - else ", article.errors)
        except Exception as e:
                    print("sense > views > except ", e)
            
    else: # GET
        article = LogDetailForm() # create empty form to add an article
        # articleForm = article.render("create_log_form.html")

        # print([x.sequence.id for x in article.fields['ecode'].queryset.all()])
        # print([x.event for x in article.fields['ecode'].queryset.all()])
        # print(article.as_div())
        return render(request, "sense/create_log.html", {
            'article' : article
        })

def updateLog(request, pk):
    log = LogDetail.objects.get(id=pk)
    form = LogDetailForm(request.POST, instance=log)
    if form.is_valid():
        form.save()
        return redirect("/show")
    else:
        return render(request, "edit_log.html", {
            'log' : log
        })

def deleteLog(request, pk):
    log = LogDetail.objects.get(id=pk)
    log.delete()
    return redirect("/show")

def clearLogs(request):
    LogDetail.objects.all().delete()
    return redirect("/show")

def showLogs(request):
    logs = LogDetail.objects.all()
    count = range(logs.count())
    return render(request, "sense/show_logs.html", {
        'logs' : logs,
        'count': count
    })
