from django.urls import path, re_path
from sense.consumers import StatusConsumer

websocket_urlpatterns = [
    re_path(r'^ws/serial/dashboard/(?P<room_code>\w+)/$', StatusConsumer.as_asgi()),
]