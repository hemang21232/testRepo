from __future__ import absolute_import, unicode_literals
import os
# import django
# from django.conf import settings
from celery import Celery


# set the default dJango settings module for 'celery-program'
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'icatecd.settings')
# django.setup()

app = Celery('icatecd')
app.config_from_object('django.conf:settings', namespace='CELERY')
app.autodiscover_tasks() # (lambda: settings.INSTALLED_APPS)


