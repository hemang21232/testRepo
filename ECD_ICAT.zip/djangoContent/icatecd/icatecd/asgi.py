"""
ASGI config for icatecd project.

It exposes the ASGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/4.0/howto/deployment/asgi/
"""

import os
# import django
from django.core.asgi import get_asgi_application
import sense.routing

from channels.auth import AuthMiddlewareStack
from channels.routing import URLRouter, ProtocolTypeRouter

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'icatecd.settings')
# django.setup()
application = get_asgi_application()


application = ProtocolTypeRouter({
    "http": get_asgi_application(),
    "websocket": AuthMiddlewareStack(
        URLRouter(
                sense.routing.websocket_urlpatterns
        )
    ),
})

# URLRouter([]) error - AttributeError: 'list' object has no attribute 'callback'
