#!/bin/bash

cd /home/djgo/djangoContent/icatecd
source ../django-env/bin/activate

python autocheck.py
python manage.py runserver

exit 0