#!/bin/bash

echo export DISPLAY=:0
# sudo -u djgo epiphany-browser -a -i --profile ~/.config --display=:0 http://127.0.0.1:8000/serial/dashboard/qwerty/
# xte "key F11" -x:0 &
sed -i 's/"exited_cleanly":false/"exited_cleanly":true/' /home/djgo/.config/chromium/Default/Preferences
sed -i 's/"exit_type":"Crashed"/"exit_type":Normal"/' /home/djgo/.config/chromium/Default/Preferences

/usr/bin/chromium-browser --noerrdialogs --disable-infobars --kiosk http://127.0.0.1:8000/serial/dashboard/qwerty &

# --display=:0 -a
# midori -e fullscreen


exit 0